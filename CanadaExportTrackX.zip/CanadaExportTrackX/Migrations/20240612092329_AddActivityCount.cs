﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddActivityCount : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ActivityCount",
                table: "HBLActivitylogHistory",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ActivityCount",
                table: "HBLActivityLog",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ActivityCount",
                table: "FileActivityLog",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ActivityCount",
                table: "FileAcitivityLogHistory",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActivityCount",
                table: "HBLActivitylogHistory");

            migrationBuilder.DropColumn(
                name: "ActivityCount",
                table: "HBLActivityLog");

            migrationBuilder.DropColumn(
                name: "ActivityCount",
                table: "FileActivityLog");

            migrationBuilder.DropColumn(
                name: "ActivityCount",
                table: "FileAcitivityLogHistory");
        }
    }
}
