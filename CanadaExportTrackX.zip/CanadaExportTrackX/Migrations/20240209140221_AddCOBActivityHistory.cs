﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddCOBActivityHistory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DAPActivity_ContainerMaster_ContainerId",
                table: "DAPActivity");

            migrationBuilder.DropColumn(
                name: "USABooking",
                table: "DAPActivity");

            migrationBuilder.AlterColumn<string>(
                name: "ContainerId",
                table: "DAPActivity",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.CreateTable(
                name: "COBActivityHistory",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    COBActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Booking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    USABooking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ETD = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_COBActivityHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_COBActivityHistory_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_COBActivityHistory_COBActivity_COBActivityId",
                        column: x => x.COBActivityId,
                        principalTable: "COBActivity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_COBActivityHistory_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_COBActivityHistory_COBActivityId",
                table: "COBActivityHistory",
                column: "COBActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivityHistory_StatusId",
                table: "COBActivityHistory",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivityHistory_UserId",
                table: "COBActivityHistory",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_DAPActivity_ContainerMaster_ContainerId",
                table: "DAPActivity",
                column: "ContainerId",
                principalTable: "ContainerMaster",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DAPActivity_ContainerMaster_ContainerId",
                table: "DAPActivity");

            migrationBuilder.DropTable(
                name: "COBActivityHistory");

            migrationBuilder.AlterColumn<string>(
                name: "ContainerId",
                table: "DAPActivity",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "USABooking",
                table: "DAPActivity",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_DAPActivity_ContainerMaster_ContainerId",
                table: "DAPActivity",
                column: "ContainerId",
                principalTable: "ContainerMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
