﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class RemoveNotNullFromCOBAndDAP : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_COBActivity_ActivityMaster_ActivityId",
                table: "COBActivity");

            migrationBuilder.DropForeignKey(
                name: "FK_FileAcitivityLogHistory_COBActivity_COBActivityId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.DropIndex(
                name: "IX_FileAcitivityLogHistory_COBActivityId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.DropIndex(
                name: "IX_COBActivity_ActivityId",
                table: "COBActivity");

            migrationBuilder.DropColumn(
                name: "COBActivityId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.DropColumn(
                name: "ActivityId",
                table: "COBActivity");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "COBActivityId",
                table: "FileAcitivityLogHistory",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActivityId",
                table: "COBActivity",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_COBActivityId",
                table: "FileAcitivityLogHistory",
                column: "COBActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_ActivityId",
                table: "COBActivity",
                column: "ActivityId");

            migrationBuilder.AddForeignKey(
                name: "FK_COBActivity_ActivityMaster_ActivityId",
                table: "COBActivity",
                column: "ActivityId",
                principalTable: "ActivityMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FileAcitivityLogHistory_COBActivity_COBActivityId",
                table: "FileAcitivityLogHistory",
                column: "COBActivityId",
                principalTable: "COBActivity",
                principalColumn: "Id");
        }
    }
}
