﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class filelogActivitysetnull : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_ActivityMaster_ActivityId",
                table: "FileActivityLog");

            migrationBuilder.AlterColumn<string>(
                name: "ActivityId",
                table: "FileActivityLog",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_ActivityMaster_ActivityId",
                table: "FileActivityLog",
                column: "ActivityId",
                principalTable: "ActivityMaster",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_ActivityMaster_ActivityId",
                table: "FileActivityLog");

            migrationBuilder.AlterColumn<string>(
                name: "ActivityId",
                table: "FileActivityLog",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_ActivityMaster_ActivityId",
                table: "FileActivityLog",
                column: "ActivityId",
                principalTable: "ActivityMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
