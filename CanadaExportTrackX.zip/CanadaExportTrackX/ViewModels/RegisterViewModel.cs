﻿using CanadaExportTrackX.DataModel;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CanadaExportTrackX.ViewModels
{
	public class RegisterViewModel
	{
		[Required]
		public string UserName { get; set; }
		[Required]
		public int EmpId { get; set; }
		[Required]
		public string CitrixId { get; set; }
		public string Role { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDelete { get; set; }
        public bool? IsLDAP { get; set; }
        public bool? IsReset { get; set; }
        public List<Role>? RoleList { get; set; }
        public List<string>? assingedRoleList { get; set; }
    }
}
