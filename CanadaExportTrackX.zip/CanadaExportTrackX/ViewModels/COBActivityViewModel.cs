﻿namespace CanadaExportTrackX.ViewModels
{
    public class COBActivityViewModel
    {
        public string Id { get; set; }
        public string HBLId { get; set; }
        public string? HBLNumber { get; set; }
        public string? FileNumber { get; set; }
        public string? ContainerNo { get; set; }
        public string? POD { get; set; }
        public DateTime? EnterDate { get; set; }
        public string? Booking { get; set; }
        public string? USABooking { get; set; }
        public DateTime? ETD { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
