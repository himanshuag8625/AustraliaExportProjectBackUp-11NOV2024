﻿namespace CanadaExportTrackX.ViewModels
{
    public class FileActivityLogViewModel
    {
        public string? FileId { get; set; }
        public string? FileLogId { get; set; }
        public string? ContainerNo { get; set; }
        public string? ContainerId { get; set; }
        public string? ActivityId { get; set; }
        public int? ActivityCount { get; set; }
        public string? TallySheetId { get; set; }
        public string? MBLReviewId { get; set; }
        public string? TallySheetComment { get; set; }
        public string? MBLReviewComment { get; set; }
        public string? TBLProcessingId { get; set; }
        public string? TBLProcessingComment { get; set; } 
        public string? BLRequestId { get; set; }
        public string? BLRequestComment { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? SI { get; set; }
        public string? UserId { get; set; }
        public string? Roe { get; set; }
        public string? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
