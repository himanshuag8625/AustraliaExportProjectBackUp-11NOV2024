﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CanadaExportTrackX.DataModel
{
    public class DAPActivity
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? ContainerId { get; set; }
        //public string HBLId { get; set; }
        public string? HBLId { get; set; }
        public string? Booking { get; set; }
        public DateTime? VesselETA { get; set; }
        public DateTime? FirstReminder { get; set; }
        public string? FirstReminderComment { get; set; }
        public string? FirstReminderStatus { get; set; }  
        public DateTime? SecondReminder { get; set; }
        public string? SecondReminderComment { get; set; }
        public string? SecondReminderStatus { get; set; }  
        public DateTime? ThirdReminder { get; set; }
        public string? ThirdReminderComment { get; set; }
        public string? ThirdReminderStatus { get; set; }
        public string? StatusId { get; set; }
        public string? UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual StatusMaster Status { get; set; } 

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } 
        public virtual ICollection<DAPActvityHistory> DAPActvityHistory { get; } = new List<DAPActvityHistory>();
        [ForeignKey("ContainerId")]
        public virtual ContainerMaster ContainerMaster { get; set; } 
        [ForeignKey("HBLId")]
        public virtual HBLMaster HBLMaster { get; set; } 
    }
}
