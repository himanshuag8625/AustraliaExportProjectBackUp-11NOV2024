﻿using CanadaExportTrackX.DataModel;
using CanadaExportTrackX.ViewModels;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CanadaExportTrackX
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDBContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDBContext>>()))
            {
                //if (context.Roles.Count() == 0)
                //{
                //    string[] roles = { "Supervisor", "Manager", "User", "QC" };
                //    foreach (string role in roles)
                //    {
                //        context.Roles.Add(new Role { Name = role });
                //    }
                //    context.SaveChanges();
                //}

                //var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();

                //var user = new ApplicationUser
                //{
                //    UserName = "TusharP",
                //    EmpId = 139289,
                //    CitrixId = "tusharp",
                //    FirstName = "Tushar",
                //    LastName = "Parik",
                //};

                

                string[] roles = new string[] { "Admin", "User", "QC", "Supervisor", "Manager" };

                var usersWithProperties = new List<UserWithProperties>
                {
                    new UserWithProperties
                    {
                        UserName = "Supervisor",
                        Wnsid = "111111",
                        CitrixId = "Supervisor",
                        FirstName = "Supervisor",
                        LastName = "Supervisor",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "Admin",
                        Wnsid = "555555",
                        CitrixId = "Admin",
                        FirstName = "Admin",
                        LastName = "Admin",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User1",
                        Wnsid = "222222",
                        CitrixId = "User1",
                        FirstName = "User1",
                        LastName = "User1",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User2",
                        Wnsid = "333333",
                        CitrixId = "User2",
                        FirstName = "User2",
                        LastName = "User2",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User3",
                        Wnsid = "444444",
                        CitrixId = "User3",
                        FirstName = "User3",
                        LastName = "User3",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "Tusharp",
                        Wnsid = "139289",
                        CitrixId = "Tusharp",
                        FirstName = "Tushar",
                        LastName = "Parik",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "RahulW",
                        Wnsid = "275401",
                        CitrixId = "RahulW",
                        FirstName = "Rahul",
                        LastName = "Waghchaure",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "VaibhavA",
                        Wnsid = "310475",
                        CitrixId = "VaibhavA",
                        FirstName = "Ravindra",
                        LastName = "More",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "RavindraM",
                        Wnsid = "326068",
                        CitrixId = "RavindraM",
                        FirstName = "Ravindra",
                        LastName = "More",                        
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "HimanshuA",
                        Wnsid = "418450",
                        CitrixId = "HimanshuA",
                        FirstName = "Himanshu",
                        LastName = "Agrawal",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },

                };

                // Process roles
                foreach (string role in roles)
                {
                    var existingRole = context.Roles.SingleOrDefault(r => r.Name == role);
                    if (existingRole == null)
                    {
                        context.Roles.Add(new Role
                        {
                            Name = role.Trim(),
                            IsActive = true,
                            IsDelete = false,
                        });
                    }
                    else
                    {
                        existingRole.Name = role.Trim();
                        existingRole.IsActive = true;
                        existingRole.IsDelete = false;
                        context.Roles.Update(existingRole);
                    }
                }

                // Process users
                foreach (var user in usersWithProperties)
                {
                    var existingUser = context.Users.SingleOrDefault(u => u.UserName == user.UserName);
                    if (existingUser == null)
                    {
                        context.Users.Add(new ApplicationUser
                        {
                            Id = Guid.NewGuid().ToString(),
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            UserName = user.UserName,
                            EmpId = Convert.ToInt32(user.Wnsid),
                            CitrixId = user.CitrixId,
                            IsActive = user.IsActive ?? true,
                            IsDelete = user.IsDelete ?? false,
                            IsLDAP = user.IsLDAP ?? true,
                            IsReset = user.IsReset ?? false,
                            NormalizedUserName = user.CitrixId?.ToUpper()
                        });
                    }
                    else
                    {
                        existingUser.EmpId = Convert.ToInt32(user.Wnsid);
                        existingUser.CitrixId = user.CitrixId;
                        existingUser.FirstName = user.FirstName;
                        existingUser.LastName = user.LastName;
                        existingUser.IsActive = user.IsActive ?? true;
                        existingUser.IsDelete = user.IsDelete ?? false;
                        existingUser.IsLDAP = user.IsLDAP ?? true;
                        existingUser.IsReset = user.IsReset ?? false;
                        existingUser.NormalizedUserName = user.CitrixId?.ToUpper();
                        context.Users.Update(existingUser);
                    }
                }

                context.SaveChanges();

                // Assign roles to users
                foreach (var user in usersWithProperties)
                {
                    var currentUser = context.Users.FirstOrDefault(u => u.UserName.ToLower() == user.UserName.ToLower());
                    var userRoles = context.UserRoles.FirstOrDefault(u => u.UserId == currentUser.Id);
                    if (userRoles == null)
                    {
                        if (currentUser != null)
                        {
                            var rolesToAdd = new List<string> { "Admin", "User", "Supervisor", "Manager" }; // Add multiple roles here
                            foreach (var roleName in rolesToAdd)
                            {
                                var role = context.Roles.FirstOrDefault(r => r.Name.ToLower() == roleName.ToLower());
                                if (role != null)
                                {
                                    var userRole = new IdentityUserRole<string>
                                    {
                                        RoleId = role.Id,
                                        UserId = currentUser.Id
                                    };
                                    context.UserRoles.Add(userRole);
                                }
                            }
                        }
                    }
                    else
                    {
                        if (currentUser != null)
                        {
                            var rolesToAdd = new List<string> { "Admin", "User", "Supervisor", "Manager" }; // Add multiple roles here
                            foreach (var roleName in rolesToAdd)
                            {
                                var role = context.Roles.FirstOrDefault(r => r.Name.ToLower() == roleName.ToLower());
                                var usersRoles = context.UserRoles.FirstOrDefault(r => r.RoleId == role.Id && r.UserId == currentUser.Id);
                                if (usersRoles != null)
                                {
                                    usersRoles.RoleId = role.Id;
                                    usersRoles.UserId = currentUser.Id;
                                    context.UserRoles.Update(usersRoles);
                                }
                                else
                                {
                                    var userRole = new IdentityUserRole<string>
                                    {
                                        RoleId = role.Id,
                                        UserId = currentUser.Id
                                    };
                                    context.UserRoles.Add(userRole);
                                }
                            }
                        }
                    }
                }
                //foreach (var user in usersWithProperties)
                //{
                //    var existingUser = context.Users.SingleOrDefault(u => u.UserName == user.UserName);
                //    if (existingUser == null)
                //    {
                //        var newUser = new ApplicationUser
                //        {
                //            Id = Guid.NewGuid().ToString(),
                //            FirstName = user.FirstName,
                //            LastName = user.LastName,
                //            UserName = user.UserName,
                //            EmpId = Convert.ToInt32(user.Wnsid),
                //            CitrixId = user.CitrixId,
                //            IsActive = user.IsActive ?? true,
                //            IsDelete = user.IsDelete ?? false,
                //            IsLDAP = user.IsLDAP ?? true,
                //            IsReset = user.IsReset ?? false,
                //            NormalizedUserName = user.CitrixId?.ToUpper()
                //        };

                //        var result = userManager.CreateAsync(newUser, "Abcd@1234").Result;
                //        if (result.Succeeded)
                //        {
                //            // Assign role to the user
                //            var roleResult = userManager.AddToRoleAsync(newUser, "Supervisor").Result;
                //            if (!roleResult.Succeeded)
                //            {
                //                // Handle role assignment failure
                //            }
                //        }
                //        else
                //        {
                //            // Handle user creation failure
                //        }
                //    }
                //    else
                //    {
                //        existingUser.EmpId = Convert.ToInt32(user.Wnsid);
                //        existingUser.CitrixId = user.CitrixId;
                //        existingUser.FirstName = user.FirstName;
                //        existingUser.LastName = user.LastName;
                //        existingUser.IsActive = user.IsActive ?? true;
                //        existingUser.IsDelete = user.IsDelete ?? false;
                //        existingUser.IsLDAP = user.IsLDAP ?? true;
                //        existingUser.IsReset = user.IsReset ?? false;
                //        existingUser.NormalizedUserName = user.CitrixId?.ToUpper();
                //        context.Users.Update(existingUser);

                //        var userManager = serviceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();
                //        var token = userManager.GeneratePasswordResetTokenAsync(existingUser).Result;
                //        var result = userManager.ResetPasswordAsync(existingUser, token, "Abcd@1234").Result;
                //    }
                //    }



                context.SaveChanges();
                //context.SaveChanges();
            }
        }
    }

}


